import { readFileSync, readdirSync, statSync } from 'node:fs';
import { resolve, relative, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

function filesIn(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? filesIn(path) : [path];
  });
}

export function checkLocalAssets(root) {
  const issues = [];
  const assetRoot = resolve(root, 'src/assets');
  const pointers = filesIn(assetRoot).filter(path => path.endsWith('.asset.json'));
  for (const pointer of pointers) {
    const metadata = JSON.parse(readFileSync(pointer, 'utf8'));
    const path = resolve(root, 'public/assets', relative(assetRoot, dirname(pointer)), metadata.original_filename);
    try {
      if (statSync(path).size !== metadata.size) issues.push(`Incomplete original asset: ${relative(root, path)}`);
      if (path.endsWith('.glb')) {
        const bytes = readFileSync(path);
        if (bytes.toString('ascii', 0, 4) !== 'glTF' || bytes.readUInt32LE(8) !== bytes.length) {
          issues.push(`Invalid GLB: ${relative(root, path)}`);
          continue;
        }
        const model = JSON.parse(bytes.toString('utf8', 20, 20 + bytes.readUInt32LE(12)));
        for (const item of [...(model.images ?? []), ...(model.buffers ?? [])]) {
          if (item.uri && !item.uri.startsWith('data:')) {
            if (/^(https?:|\/\/)/.test(item.uri)) issues.push(`Remote model dependency: ${item.uri}`);
            else {
              try { statSync(resolve(dirname(path), decodeURIComponent(item.uri))); }
              catch { issues.push(`Missing model dependency: ${item.uri}`); }
            }
          }
        }
      }
    } catch {
      issues.push(`Missing or unreadable original asset: ${relative(root, path)}`);
    }
  }
  for (const path of filesIn(resolve(root, 'src')).filter(path => /\.(tsx?|css)$/.test(path))) {
    const source = readFileSync(path, 'utf8');
    if (source.includes('/__l5e/') || /(?:from\s*|import\s*)["'][^"']*\.asset\.json/.test(source)) {
      issues.push(`Hosted-only asset reference: ${relative(root, path)}`);
    }
    for (const match of source.matchAll(/["'](\/assets\/[^"']+)["']/g)) {
      try { statSync(resolve(root, 'public', match[1].slice(1))); }
      catch { issues.push(`Missing referenced asset: ${match[1]}`); }
    }
  }
  return { count: pointers.length, issues };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const { count, issues } = checkLocalAssets(root);
  if (issues.length) {
    console.error(`AstroQuest asset check failed:\n${issues.join('\n')}\nRestore public/assets from the complete portable download before starting.`);
    process.exitCode = 1;
  } else {
    console.log(`AstroQuest: all ${count} original assets and local references verified.`);
  }
}