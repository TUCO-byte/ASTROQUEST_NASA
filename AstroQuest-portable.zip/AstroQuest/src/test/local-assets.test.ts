import { describe, expect, it } from 'vitest';
import { readFileSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { tmpdir } from 'node:os';

describe('Portable original assets', () => {
  it('includes the original Earth, Moon, Mars, terrain, logos and both astronaut models', async () => {
    const { checkLocalAssets } = await import('../../scripts/check-local-assets.mjs');
    expect(checkLocalAssets(resolve('.'))).toEqual({ count: 15, issues: [] });
    for (const name of ['earth.jpg', 'moon-world.jpg', 'mars-globe.jpg']) {
      const bytes = readFileSync(resolve('public/assets/textures', name));
      expect(bytes.subarray(0, 2).toString('hex')).toBe('ffd8');
    }
  });

  it('rejects an export that omitted an original texture', async () => {
    const { checkLocalAssets } = await import('../../scripts/check-local-assets.mjs');
    const root = mkdtempSync(join(tmpdir(), 'astroquest-assets-'));
    try {
      mkdirSync(join(root, 'src/assets/textures'), { recursive: true });
      writeFileSync(join(root, 'src/assets/textures/earth.jpg.asset.json'), JSON.stringify({ original_filename: 'earth.jpg', size: 1392914 }));
      expect(checkLocalAssets(root).issues).toContain('Missing or unreadable original asset: public/assets/textures/earth.jpg');
    } finally {
      rmSync(root, { recursive: true, force: true });
    }
  });
});